clear
clc
close all
dos('del *.asv')
format longEng

x = zeros(2,2);
y = [10*x(1)+ 0.4*x(2)^3- 5*x(2)^2; 
      0.4*x(1)^3-3*x(1)^2+ 10*x(2)];
%------------------------------------------------------------------------
NR=1;

psi=1.0;
deltalL=0.65316;                                                            % arch-length
%------------------------------------------------------------------------
figure(1)
set(1,'Color','w')
set(1,'Position',[300 80 550*2 300*2])
set(gca,'Fontsize',16)
h1=plot(x,y,'b'); hold on
grid on
ylim([0 0.28])
h2=FPLOT(['x.^2+','(y.*',num2str(psi),').^2=',num2str(deltalL^2)],[0 pi./2]);
set(h2,'LineWidth',2,'LineStyle','--');
axis equal
%------------------------------------------------------------------------
max_iter=500;
tol=1e-6;   
Residual=1;                                                                % 1 is not the exact value, just used for stating the iteration
delta_lambda_ini=deltalL./sqrt(1+psi.^2);                                  %
%
iter=1;
q_ref=1.0;
lambda=0;
p=0;
%%%%%%%%%%%%%%%%%%%%%%%%%
while (iter<=max_iter+1 && Residual>=tol)
    %
    if iter==1
        delta_lambda(iter)=delta_lambda_ini;
        F_ini=F_internal(p(iter));
        F_ext=delta_lambda(iter)*q_ref;
        Residual=F_ext-F_ini;
        k=k_stiff(p(iter));
        delta_p(iter+1)=Residual/k;
        %----------------------------------------------------------------
        % update load factor and displacement
        %----------------------------------------------------------------
        lambda(iter+1)=lambda(iter)+delta_lambda(iter);
        p(iter+1)=p(iter)+delta_p(iter+1);
        delta_lambda(iter+1)=delta_lambda(iter);
    else
        if NR==1
            k=abs(k_stiff(p(iter)));
        elseif NR==2
            k=k;
        end
        F_ini=F_internal(p(iter));
        F_ext=lambda(iter)*q_ref;
        Residual=F_ext-F_ini;
        %
        %
        delta_p_bar=Residual./k;
        delta_p_t=q_ref./k;
        a1=delta_p_t'*delta_p_t+psi*q_ref*q_ref;
        a2=2*delta_p_t'*(delta_p(iter)+delta_p_bar)+2*delta_lambda(iter)*(psi^2)*q_ref*q_ref;
        a3=(delta_p(iter)+delta_p_bar)'*(delta_p(iter)+delta_p_bar)-deltalL^2+(delta_lambda(iter)^2)*(psi^2)*q_ref*q_ref;
        %
        %
        ddelta_lambda=lambda_solv(a1,a2,a3);
        %
        %
        delta_lambda(iter+1)=delta_lambda(iter)+ddelta_lambda;
        delta_p(iter+1)=delta_p(iter)+delta_p_bar+ddelta_lambda*delta_p_t;
        %
        lambda(iter+1)=0+delta_lambda(iter+1);
        p(iter+1)=0+delta_p(iter+1);
        %
    end
    %
    %
    disp('iter = ');disp(iter)
    %
    h3=plot(p,lambda*q_ref,'r-o','Markersize',5,'Markerfacecolor','r');
    %
    if iter>=2
        line([p(iter) p(iter)],[F_ini F_ext],'LineStyle','-','Color',[1 0 0])
        plot(p(iter),F_ini,'ro','Markersize',5,'Markerfacecolor','r'); hold on
        line([p(iter) p(iter+1)],[F_ini lambda(iter+1)*q_ref],'LineStyle','-','Color',[1 0 0])
    end
    title(['Iteration = ',num2str(iter),' ','Residual = ',num2str(Residual * 9999, '%10.5e\n')])
    legend([h1 h2 h3],'Analytical solution','Arch length','Iteration')
    xlabel('Displacement')
    ylabel('Force \lambda*R')
    %
    pause(0.2)
    %
    iter=iter+1;
    %
end
function y=k_stiff(x)
%%%%%%%%%%%%%%%%%%%%%%%%%
% Derivation of function 
% Normally, in this part, the global stiffness matrix comes from the
% FEM model
%%%%%%%%%%%%%%%%%%%%%%%%%
y=[10 + 0.12*x(2)^2 - 10*x(2)  
       0.12*x(1)^2-6*x(1)-10];
%
return
end
function y=F_internal(x)
%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Normally, in this part, the internal nodal force verctor comes from the
% FEM model
%%%%%%%%%%%%%%%%%%%%%%%%%
y=[10*x(1)+ 0.4*x(2)^3- 5*x(2)^2; 
      0.4*x(1)^3-3*x(1)^2+ 10*x(2)];
%
return
end
