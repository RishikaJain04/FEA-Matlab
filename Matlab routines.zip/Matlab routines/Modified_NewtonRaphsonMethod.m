function B = Modified_NewtonRaphsonMethod(~)

    tol = 1.0e-5;
iter = 0;
u = [0; 0];
uold = u;
c = 0;
f = [40; 15];
P = [10*u(1)+ 0.4*u(2)^3- 5*u(2)^2; 
      0.4*u(1)^3-3*u(1)^2+ 10*u(2)];
R = P-f;
conv= (R(1)^2+R(2)^2)/(1+f(1)^2+f(2)^2);
fprintf('\n iter      u1      u2         conv       c');
fprintf('\n %3d  %7.5f %7.5f %12.3e %7.5f',iter,u(1),u(2),conv,c);
Kt = [10 + 0.12*u(2)^2 - 10*u(2);  
       0.12*u(1)^2-6*u(1)-10];
while conv > tol && iter < 100
 delu = Kt\R;
 u = uold + delu;
 P = [10*u(1)+ 0.4*u(2)^3- 5*u(2)^2; 
      0.4*u(1)^3-3*u(1)^2+ 10*u(2)];
 R = P-f;
 conv= (R(1)^2+R(2)^2)/(1+f(1)^2+f(2)^2);
 c = abs(0.9-u(2))/abs(0.9-uold(2))^2;
 uold = u;
 iter = iter + 1;
 fprintf('\n %3d  %7.5f %7.5f %12.3e %7.5f',iter,u(1),u(2),conv,c);
end
end
